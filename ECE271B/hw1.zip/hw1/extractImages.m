function [folderImages] = extractImages(mainDir)

% Get a list of all files and folders in this folder
files = dir(mainDir);

% Initialize the outer cell array
folderImages = {};

% Loop through them to find folders
for k = 1:length(files)
    if files(k).isdir && ~strcmp(files(k).name, '.') && ~strcmp(files(k).name, '..')
        % It's a folder, construct the path to the folder
        folderPath = fullfile(mainDir, files(k).name);

        % Get a list of all images in this folder (assuming JPEG and PNG formats)
        imgFiles = dir(fullfile(folderPath, '*.jpg'));
        imgFiles = [imgFiles; dir(fullfile(folderPath, '*.png'))];

        % Initialize the inner cell array for this folder
        images = {};

        % Loop through each image
        for m = 1:length(imgFiles)
            % Construct the path to the image
            imgPath = fullfile(folderPath, imgFiles(m).name);

            % Read the image
            img = imread(imgPath);

            % Store the image in the inner cell array
            images{end + 1} = img;
        end

        % Store the inner cell array in the outer cell array
        folderImages{end + 1} = images;
    end
end

% folderImages now contains a cell array for each folder, each containing images
end