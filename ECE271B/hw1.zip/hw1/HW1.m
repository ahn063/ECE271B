%Andy Nguyen
%1/18/2024
%ECE 271B
%% Setup
close all; clear; clc;
% Get training set
mainDir = 'X:\ECE\ECE271B\hw1\trainset';
folderList = extractImages(mainDir);
numImages = sum(cellfun(@(c) length(c), folderList));
%% Part a: compute PCA of the data and make a 4x4 plot showing 16 principal components of largest variance

%reshape 50x50 matrix into 2500 dimensional vector and add to final matrix
X = zeros(2500, numImages); 
imageIndex = 1;
for j = 1:length(folderList)
    for i = 1:length(folderList{j})
        imgVector = reshape(folderList{j}{i}, [2500, 1]);
        X(:, imageIndex) = imgVector;
        imageIndex = imageIndex + 1;
    end
end
%make values of A from 0 to 1
X = X/255.0;
X_mean = sum(X, 2)/size(X,2);
X_centered = X-X_mean;
[M, E, N] = svd(X_centered');

top16PC = diag(E(1:16, 1:16));
%create 4x4 plot
figure();
for i = 1:16
    subplot(4,4,i)
    bar(i, top16PC(i))
    xlabel('Index')
    ylabel('Eigenvalue')
    title(sprintf('%i', i))
end

%% Part B
figure();
plotIndex = 1;
for class1Index = 1:length(folderList)-1
    for class2Index = class1Index+1:length(folderList)
        A = zeros(2500, length(folderList{class1Index}));
        B = zeros(2500, length(folderList{class2Index}));
        
        for i = 1:length(folderList{class1Index})
            imgVectorA = reshape(folderList{class1Index}{i}, [2500, 1]);
            A(:, i) = imgVectorA;
            imgVectorB = reshape(folderList{class2Index}{i}, [2500, 1]);
            B(:, i) = imgVectorB;
        end
        A = A/255.0;
        B = B/255.0;
        A_mean = sum(A, 2) / size(A, 2);
        B_mean = sum(B, 2) / size(B, 2);
        A_cov = A*A';
        B_cov = B*B';
        S_w = A_cov + B_cov;
        S_b = (A_mean - B_mean) * (A_mean - B_mean)';
        
        gamma = 1;
        w = inv(A_cov + B_cov)*(A_mean - B_mean);
        
        subplot(4,4, plotIndex)
        projA = A'*w;
        projB = B'*w;
        hold on;
        scatter(projA, zeros(size(projA)), 'r*')
        scatter(projB, zeros(size(projA)), 'b.')    
        title(sprintf("Class %i vs. Class %i", class1Index, class2Index))
        xlabel('Projection Value')
        legend(sprintf("Class %i", class1Index), sprintf("Class %i", class2Index))
        plotIndex = plotIndex + 1;
        
    end
end

%% Part C



